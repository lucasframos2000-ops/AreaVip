export type DeviceType = 'mobile' | 'tablet' | 'desktop' | 'fullscreen';

export type SourceMode = 'live' | 'mirror';

export interface DeviceConfig {
  id: DeviceType;
  name: string;
  width: number | string;
  height: number | string;
  icon: string;
  description: string;
}

export interface PingData {
  status: 'checking' | 'online' | 'offline' | 'slow';
  latencyMs?: number;
  lastChecked?: Date;
  httpStatus?: number;
}
