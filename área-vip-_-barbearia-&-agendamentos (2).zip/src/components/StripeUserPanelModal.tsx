import React, { useState, useEffect } from 'react';
import { CreditCard, CheckCircle2, ShieldCheck, ExternalLink, Settings, Sparkles, X, AlertCircle } from 'lucide-react';
import { db } from '../lib/firebase';
import { collection, onSnapshot } from 'firebase/firestore';

interface StripeUserPanelModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface StripeConfigState {
  publishableKey: string;
  isConfigured: boolean;
  mode: 'test' | 'live';
  currency: string;
}

export const StripeUserPanelModal: React.FC<StripeUserPanelModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'subscription' | 'settings'>('subscription');
  const [stripeConfig, setStripeConfig] = useState<StripeConfigState>({
    publishableKey: '',
    isConfigured: false,
    mode: 'test',
    currency: 'BRL',
  });
  const [loading, setLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  // Stripe credentials form
  const [pubKeyInput, setPubKeyInput] = useState('');
  const [secKeyInput, setSecKeyInput] = useState('');

  // Selected subscription plan
  const [selectedPlan, setSelectedPlan] = useState<'bronze' | 'prata' | 'ouro' | 'premium'>('ouro');
  const [activeSubscription, setActiveSubscription] = useState<any>({
    planName: 'Plano Ouro VIP',
    priceMonthly: 119.90,
    status: 'active',
    periodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString('pt-BR'),
    paymentMethod: 'Cartão de Crédito via Stripe',
    cutsLeft: 'Ilimitados'
  });

  useEffect(() => {
    // Fetch current Stripe config from server
    fetch('/api/stripe/config')
      .then(res => res.json())
      .then(data => {
        setStripeConfig(data);
        setPubKeyInput(data.publishableKey || '');
      })
      .catch(err => console.error('Erro ao buscar config do Stripe:', err));

    // Listen to subscriptions in Firestore
    try {
      const unsub = onSnapshot(collection(db, 'subscriptions'), (snapshot) => {
        if (!snapshot.empty) {
          const doc = snapshot.docs[0]?.data();
          if (doc) {
            setActiveSubscription((prev: any) => ({
              ...prev,
              planName: doc.planName || prev.planName,
              priceMonthly: doc.priceMonthly || doc.amount || prev.priceMonthly,
              status: doc.status || 'active',
              periodEnd: doc.periodEnd || prev.periodEnd
            }));
          }
        }
      }, (e) => {
        console.warn('Firestore snapshot note:', e);
      });
      return () => unsub();
    } catch (e) {
      console.warn('Firestore subscription listen:', e);
    }
  }, []);

  if (!isOpen) return null;

  const handleSaveKeys = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setStatusMessage(null);

    try {
      const res = await fetch('/api/stripe/update-keys', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          publishableKey: pubKeyInput,
          secretKey: secKeyInput,
          mode: secKeyInput.startsWith('sk_live_') ? 'live' : 'test'
        })
      });
      const data = await res.json();
      if (data.success) {
        setStatusMessage({ type: 'success', text: 'Chaves do Stripe salvas e ativadas com sucesso!' });
        setStripeConfig(prev => ({
          ...prev,
          publishableKey: pubKeyInput,
          isConfigured: data.isConfigured,
          mode: data.mode
        }));
      } else {
        setStatusMessage({ type: 'error', text: 'Erro ao salvar credenciais do Stripe.' });
      }
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: err.message || 'Falha de comunicação.' });
    } finally {
      setLoading(false);
    }
  };

  const handleStartStripeCheckout = async (planKey: string, planName: string, price: number) => {
    setLoading(true);
    setStatusMessage({ type: 'info', text: 'Iniciando checkout seguro Stripe...' });

    try {
      const res = await fetch('/api/stripe/checkout-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          planId: `plan-${planKey}`,
          planName: planName,
          priceMonthly: price,
          userName: 'Cliente Área VIP',
          userEmail: 'cliente@areavip.com'
        })
      });

      const data = await res.json();
      if (data.url) {
        setStatusMessage({ type: 'success', text: 'Redirecionando para o Stripe Checkout...' });
        window.location.href = data.url;
      } else {
        setStatusMessage({ type: 'error', text: 'Não foi possível gerar a sessão Stripe.' });
      }
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: err.message || 'Erro ao conectar com Stripe.' });
    } finally {
      setLoading(false);
    }
  };

  const handleOpenCustomerPortal = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/stripe/portal-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ customerId: 'cus_active_customer' })
      });
      const data = await res.json();
      if (data.url) {
        window.open(data.url, '_blank');
      }
    } catch (e: any) {
      setStatusMessage({ type: 'error', text: 'Erro ao abrir Portal Stripe.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-[#0c0c0c] border border-amber-500/30 rounded-3xl shadow-2xl overflow-hidden text-zinc-100 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800/80 bg-zinc-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Área VIP & Pagamentos Stripe
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                  stripeConfig.isConfigured 
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                    : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                }`}>
                  {stripeConfig.isConfigured ? (stripeConfig.mode === 'live' ? 'Stripe Live' : 'Stripe Test') : 'Modo Seguro'}
                </span>
              </h2>
              <p className="text-xs text-zinc-400">Gerenciamento de assinaturas do Clube VIP e faturas</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-zinc-400 hover:text-white hover:bg-zinc-800/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab navigation */}
        <div className="flex border-b border-zinc-800 bg-zinc-900/40 px-6">
          <button
            onClick={() => setActiveTab('subscription')}
            className={`py-3 px-4 text-xs font-bold transition-all border-b-2 ${
              activeTab === 'subscription'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Minha Assinatura VIP
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`py-3 px-4 text-xs font-bold transition-all border-b-2 flex items-center gap-1.5 ${
              activeTab === 'settings'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            Configuração de Chaves Stripe
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {statusMessage && (
            <div className={`p-3.5 rounded-2xl text-xs flex items-center gap-2.5 ${
              statusMessage.type === 'success'
                ? 'bg-emerald-950/40 border border-emerald-500/40 text-emerald-300'
                : statusMessage.type === 'error'
                ? 'bg-red-950/40 border border-red-500/40 text-red-300'
                : 'bg-blue-950/40 border border-blue-500/40 text-blue-300'
            }`}>
              {statusMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0" />
              )}
              <span>{statusMessage.text}</span>
            </div>
          )}

          {activeTab === 'subscription' && (
            <>
              {/* Active Plan Card */}
              <div className="p-5 rounded-3xl bg-gradient-to-br from-amber-500/10 via-zinc-900/90 to-zinc-950 border border-amber-500/30 relative overflow-hidden">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 bg-amber-400/10 px-2.5 py-1 rounded-full border border-amber-400/20">
                      Plano Ativo no Stripe
                    </span>
                    <h3 className="text-xl font-black text-white mt-2 flex items-center gap-2">
                      {activeSubscription.planName}
                      <Sparkles className="w-4 h-4 text-amber-400" />
                    </h3>
                    <p className="text-xs text-zinc-400 mt-0.5">
                      Renovação automática • Cobrança mensal via Stripe
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-black text-amber-400">
                      R$ {activeSubscription.priceMonthly.toFixed(2).replace('.', ',')}
                    </div>
                    <span className="text-[11px] text-zinc-400">por mês</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 mt-4 pt-4 border-t border-zinc-800/80 text-xs">
                  <div>
                    <span className="text-zinc-500 block text-[10px]">Cortes Disponíveis</span>
                    <span className="font-bold text-zinc-200">{activeSubscription.cutsLeft}</span>
                  </div>
                  <div>
                    <span className="text-zinc-500 block text-[10px]">Próxima Renovação</span>
                    <span className="font-bold text-zinc-200">{activeSubscription.periodEnd}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3 mt-4">
                  <button
                    onClick={handleOpenCustomerPortal}
                    disabled={loading}
                    className="flex-1 py-2.5 px-3 rounded-xl bg-zinc-800/80 hover:bg-zinc-700 text-xs font-bold text-zinc-200 hover:text-white transition-all flex items-center justify-center gap-1.5 border border-zinc-700"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    Portal de Cobrança Stripe
                  </button>
                </div>
              </div>

              {/* Upgrade or Subscribe Plans */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  Mudar de Plano com Stripe Checkout
                </h4>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {[
                    { id: 'prata', name: 'Plano Prata', price: 79.90, desc: 'Até 4 cortes por mês + toalha quente' },
                    { id: 'ouro', name: 'Plano Ouro VIP', price: 119.90, desc: 'Cortes ILIMITADOS + Barba completa' },
                    { id: 'premium', name: 'Plano Premium', price: 69.90, desc: 'Cortes de cabelo ilimitados sem fidelidade' },
                    { id: 'diamante', name: 'Plano Diamante', price: 110.00, desc: 'Corte Pai e Filho com agendamento prioritário' }
                  ].map(plan => (
                    <button
                      key={plan.id}
                      onClick={() => handleStartStripeCheckout(plan.id, plan.name, plan.price)}
                      disabled={loading}
                      className="p-3.5 rounded-2xl bg-zinc-900/60 hover:bg-zinc-800/80 border border-zinc-800 hover:border-amber-500/50 text-left transition-all group flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex justify-between items-center">
                          <span className="font-bold text-sm text-white group-hover:text-amber-400 transition-colors">
                            {plan.name}
                          </span>
                          <span className="text-xs font-black text-amber-400">
                            R$ {plan.price.toFixed(2).replace('.', ',')}
                          </span>
                        </div>
                        <p className="text-[11px] text-zinc-400 mt-1 leading-snug">{plan.desc}</p>
                      </div>
                      <span className="text-[10px] font-bold text-amber-400/90 mt-2 block group-hover:underline">
                        Assinar via Stripe →
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}

          {activeTab === 'settings' && (
            <form onSubmit={handleSaveKeys} className="space-y-4">
              <div className="p-4 rounded-2xl bg-zinc-900/40 border border-zinc-800/80 text-xs text-zinc-300 space-y-1">
                <span className="font-bold text-white block">Credenciais Oficiais da sua Conta Stripe</span>
                <p className="text-zinc-400 text-[11px]">
                  Insira a sua <strong>Publishable Key</strong> (`pk_test_...` ou `pk_live_...`) e a <strong>Secret Key</strong> (`sk_test_...` ou `sk_live_...`) obtidas no seu painel Stripe (Developers &gt; API Keys).
                </p>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-zinc-300 block">
                  Stripe Publishable Key
                </label>
                <input
                  type="text"
                  value={pubKeyInput}
                  onChange={(e) => setPubKeyInput(e.target.value)}
                  placeholder="pk_test_... ou pk_live_..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 focus:border-amber-500 focus:outline-none text-xs text-white font-mono"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-zinc-300 block">
                  Stripe Secret Key
                </label>
                <input
                  type="password"
                  value={secKeyInput}
                  onChange={(e) => setSecKeyInput(e.target.value)}
                  placeholder="sk_test_... ou sk_live_..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 focus:border-amber-500 focus:outline-none text-xs text-white font-mono"
                />
              </div>

              <div className="p-3.5 rounded-2xl bg-black/40 border border-zinc-800/60 text-[11px] text-zinc-400 space-y-1">
                <span className="font-bold text-zinc-300 block">Webhook URL para Ativação Automática:</span>
                <code className="text-amber-400 font-mono block bg-zinc-950 px-2 py-1 rounded-md select-all">
                  /api/stripe/webhook
                </code>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs uppercase tracking-wider transition-all disabled:opacity-50"
              >
                {loading ? 'Salvando...' : 'Salvar Credenciais do Stripe'}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
