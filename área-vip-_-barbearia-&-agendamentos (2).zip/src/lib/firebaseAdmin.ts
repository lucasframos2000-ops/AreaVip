import { initializeApp, getApps, getApp, cert, App } from 'firebase-admin/app';
import { getFirestore, Firestore } from 'firebase-admin/firestore';
import { getAuth, Auth } from 'firebase-admin/auth';
import fs from 'fs';
import path from 'path';

let adminApp: App | null = null;

export function getFirebaseAdmin(): App {
  const existingApps = getApps();
  if (existingApps.length > 0) {
    return existingApps[0]!;
  }

  try {
    const serviceAccountPath = path.resolve(process.cwd(), 'serviceAccountKey.json');
    if (fs.existsSync(serviceAccountPath)) {
      const serviceAccount = JSON.parse(fs.readFileSync(serviceAccountPath, 'utf8'));
      adminApp = initializeApp({
        credential: cert(serviceAccount)
      });
      console.log('[Firebase Admin] Inicializado com serviceAccountKey.json');
    } else if (process.env.FIREBASE_CONFIG) {
      adminApp = initializeApp();
      console.log('[Firebase Admin] Inicializado com credenciais padrão do ambiente');
    } else {
      adminApp = initializeApp({
        projectId: 'gen-lang-client-0519360631'
      });
      console.log('[Firebase Admin] Inicializado com projectId gen-lang-client-0519360631');
    }
  } catch (error) {
    console.warn('[Firebase Admin] Aviso ao inicializar admin SDK:', error);
    const existing = getApps();
    if (!existing.length) {
      adminApp = initializeApp({
        projectId: 'gen-lang-client-0519360631'
      });
    } else {
      adminApp = existing[0]!;
    }
  }

  return adminApp || getApps()[0]!;
}

export const adminDb = (): Firestore => {
  const app = getFirebaseAdmin();
  return getFirestore(app);
};

export const adminAuth = (): Auth => {
  const app = getFirebaseAdmin();
  return getAuth(app);
};
