import { collection, doc, setDoc, getDocs, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from './firebase';

export interface FirestoreAppointment {
  id: string;
  clientName: string;
  clientPhone: string;
  clientEmail?: string;
  barberId: string;
  barberName: string;
  serviceIds: string[];
  serviceNames: string[];
  totalPrice: number;
  date: string;
  time: string;
  status: 'confirmed' | 'pending' | 'cancelled' | 'completed';
  createdAt: string;
}

// Save or sync appointment with Firestore
export async function saveAppointmentToFirestore(appointment: FirestoreAppointment) {
  try {
    const docRef = doc(db, 'appointments', appointment.id);
    await setDoc(docRef, {
      ...appointment,
      updatedAt: new Date().toISOString()
    }, { merge: true });
    return { success: true };
  } catch (error) {
    console.error('[Firebase] Erro ao salvar agendamento no Firestore:', error);
    return { success: false, error };
  }
}

// Get all appointments from Firestore
export async function getAppointmentsFromFirestore(): Promise<FirestoreAppointment[]> {
  try {
    const q = query(collection(db, 'appointments'), orderBy('date', 'desc'));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(d => d.data() as FirestoreAppointment);
  } catch (error) {
    console.error('[Firebase] Erro ao buscar agendamentos:', error);
    return [];
  }
}

// Real-time listener for appointments
export function subscribeToAppointments(callback: (appointments: FirestoreAppointment[]) => void) {
  try {
    const q = query(collection(db, 'appointments'));
    return onSnapshot(q, (snapshot) => {
      const appointments = snapshot.docs.map(d => d.data() as FirestoreAppointment);
      callback(appointments);
    }, (err) => {
      console.warn('[Firebase] Snapshot error:', err);
    });
  } catch (err) {
    console.error('[Firebase] Erro ao subscrever agendamentos:', err);
    return () => {};
  }
}
