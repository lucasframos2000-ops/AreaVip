import Stripe from 'stripe';
import fs from 'fs';
import path from 'path';
import { adminDb } from './firebaseAdmin';

// Helper to get active Stripe secret key from env or settings
export function getStripeSecretKey(): string {
  if (process.env.STRIPE_SECRET_KEY && !process.env.STRIPE_SECRET_KEY.includes('placeholder')) {
    return process.env.STRIPE_SECRET_KEY;
  }

  try {
    const dataPath = path.resolve(process.cwd(), 'src/data/initialData.json');
    if (fs.existsSync(dataPath)) {
      const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
      if (data.settings?.stripe?.secretKey) {
        return data.settings.stripe.secretKey;
      }
    }
  } catch (err) {
    console.warn('[Stripe] Could not read secretKey from settings:', err);
  }

  return process.env.STRIPE_SECRET_KEY || 'sk_test_placeholder_key_for_setup';
}

export function getStripePublishableKey(): string {
  if (process.env.VITE_STRIPE_PUBLISHABLE_KEY && !process.env.VITE_STRIPE_PUBLISHABLE_KEY.includes('placeholder')) {
    return process.env.VITE_STRIPE_PUBLISHABLE_KEY;
  }

  try {
    const dataPath = path.resolve(process.cwd(), 'src/data/initialData.json');
    if (fs.existsSync(dataPath)) {
      const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
      if (data.settings?.stripe?.publishableKey) {
        return data.settings.stripe.publishableKey;
      }
    }
  } catch (err) {
    console.warn('[Stripe] Could not read publishableKey from settings:', err);
  }

  return process.env.VITE_STRIPE_PUBLISHABLE_KEY || 'pk_test_sample_vipbarber';
}

export function isStripeLive(): boolean {
  const key = getStripeSecretKey();
  return key.startsWith('sk_live_');
}

export function isStripeConfigured(): boolean {
  const key = getStripeSecretKey();
  return (key.startsWith('sk_test_') || key.startsWith('sk_live_')) && !key.includes('placeholder');
}

// Get initialized Stripe instance
export function getStripeInstance(): Stripe {
  const key = getStripeSecretKey();
  return new Stripe(key, {
    apiVersion: '2026-02-01.acacia' as any,
    typescript: true,
  });
}

export interface CreateSubscriptionCheckoutParams {
  userId: string;
  userEmail: string;
  userName: string;
  planId: string;
  planName: string;
  priceMonthly: number;
  successUrl: string;
  cancelUrl: string;
  metadata?: Record<string, string>;
}

/**
 * Creates or retrieves a Stripe Customer
 */
export async function getOrCreateStripeCustomer(email: string, name: string, userId: string): Promise<string> {
  const stripe = getStripeInstance();
  if (!isStripeConfigured()) {
    return `cus_mock_${userId}`;
  }

  try {
    const existing = await stripe.customers.list({ email, limit: 1 });
    if (existing.data.length > 0 && existing.data[0]) {
      return existing.data[0].id;
    }

    const customer = await stripe.customers.create({
      email,
      name,
      metadata: {
        userId,
        app: 'areavip_barbearia'
      }
    });

    return customer.id;
  } catch (err: any) {
    console.warn('[Stripe] Customer search/create failed, fallback to direct:', err.message);
    return `cus_fallback_${userId}`;
  }
}

/**
 * Creates a Stripe Checkout Session for VIP Subscription
 */
export async function createStripeSubscriptionCheckout(params: CreateSubscriptionCheckoutParams) {
  const stripe = getStripeInstance();
  const configured = isStripeConfigured();

  if (!configured) {
    const mockSessionId = 'cs_test_' + Math.random().toString(36).substring(2, 14);
    
    // Save locally to Firestore for instant simulation
    try {
      const db = adminDb();
      await db.collection('subscriptions').doc(`sub_${mockSessionId}`).set({
        id: `sub_${mockSessionId}`,
        userId: params.userId,
        userEmail: params.userEmail,
        userName: params.userName,
        planId: params.planId,
        planName: params.planName,
        status: 'active',
        priceMonthly: params.priceMonthly,
        paymentMethod: 'stripe_card',
        stripeSessionId: mockSessionId,
        createdAt: new Date().toISOString(),
        isTestMode: true,
      }, { merge: true });
    } catch (e) {
      console.warn('[Firestore] Pending subscription save note:', e);
    }

    return {
      id: mockSessionId,
      url: `${params.successUrl}?session_id=${mockSessionId}&stripe_mode=test_ready`,
      isMock: true,
      mode: 'test_simulation'
    };
  }

  try {
    const customerId = await getOrCreateStripeCustomer(params.userEmail, params.userName, params.userId);

    const sessionParams: any = {
      payment_method_types: ['card'],
      mode: 'subscription',
      customer: customerId.startsWith('cus_mock') ? undefined : customerId,
      customer_email: customerId.startsWith('cus_mock') ? params.userEmail : undefined,
      line_items: [
        {
          price_data: {
            currency: 'brl',
            product_data: {
              name: `Clube VIP - ${params.planName}`,
              description: `Assinatura mensal com cortes e vantagens exclusivas na Barbearia Área VIP.`,
              metadata: {
                planId: params.planId,
              }
            },
            unit_amount: Math.round(params.priceMonthly * 100),
            recurring: {
              interval: 'month',
            },
          },
          quantity: 1,
        },
      ],
      success_url: `${params.successUrl}?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: params.cancelUrl,
      metadata: {
        userId: params.userId,
        planId: params.planId,
        planName: params.planName,
        ...params.metadata,
      },
    };

    const session = await stripe.checkout.sessions.create(sessionParams);

    return {
      id: session.id,
      url: session.url,
      isMock: false,
      mode: isStripeLive() ? 'live' : 'test'
    };
  } catch (error: any) {
    console.error('[Stripe] Error creating subscription checkout:', error);
    throw new Error(error.message || 'Falha ao conectar com Stripe');
  }
}

/**
 * Creates a Stripe PaymentIntent for single appointment payments
 */
export async function createStripePaymentIntent(amount: number, metadata: Record<string, string>) {
  const stripe = getStripeInstance();
  const configured = isStripeConfigured();

  if (!configured) {
    const mockIntentId = 'pi_test_' + Math.random().toString(36).substring(2, 14);
    return {
      clientSecret: `${mockIntentId}_secret_test`,
      id: mockIntentId,
      isMock: true,
      status: 'succeeded'
    };
  }

  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(amount * 100),
      currency: 'brl',
      automatic_payment_methods: {
        enabled: true,
      },
      metadata,
    });

    return {
      clientSecret: paymentIntent.client_secret,
      id: paymentIntent.id,
      isMock: false,
      status: paymentIntent.status
    };
  } catch (err: any) {
    console.error('[Stripe] Error creating PaymentIntent:', err);
    throw new Error(err.message || 'Falha ao processar pagamento via Stripe');
  }
}

/**
 * Creates Customer Portal Session for managing cards and cancelling subscriptions
 */
export async function createStripePortalSession(customerId: string, returnUrl: string) {
  const stripe = getStripeInstance();
  if (!isStripeConfigured() || customerId.startsWith('cus_mock')) {
    return {
      url: `${returnUrl}?portal_status=simulated`,
      isMock: true,
    };
  }

  try {
    const portal = await stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: returnUrl,
    });
    return {
      url: portal.url,
      isMock: false,
    };
  } catch (err: any) {
    console.error('[Stripe] Portal error:', err);
    throw new Error(err.message || 'Não foi possível abrir o portal Stripe');
  }
}

/**
 * Verifies a completed checkout session upon return from Stripe
 */
export async function verifyAndActivateStripeSession(sessionId: string) {
  const stripe = getStripeInstance();
  let subscriptionData: any = null;

  if (!isStripeConfigured() || sessionId.startsWith('cs_test_')) {
    subscriptionData = {
      sessionId,
      status: 'active',
      planId: 'plan-ouro',
      planName: 'Plano Ouro VIP',
      amount: 119.90,
      activatedAt: new Date().toISOString(),
      isTest: true
    };
  } else {
    try {
      const session = await stripe.checkout.sessions.retrieve(sessionId, {
        expand: ['subscription', 'customer']
      });

      subscriptionData = {
        sessionId: session.id,
        customerId: typeof session.customer === 'string' ? session.customer : session.customer?.id,
        subscriptionId: typeof session.subscription === 'string' ? session.subscription : session.subscription?.id,
        status: session.payment_status === 'paid' ? 'active' : 'pending',
        userId: session.metadata?.userId,
        planId: session.metadata?.planId,
        planName: session.metadata?.planName,
        amount: session.amount_total ? session.amount_total / 100 : 0,
        activatedAt: new Date().toISOString()
      };
    } catch (e: any) {
      console.warn('[Stripe] Session retrieve fallback:', e.message);
      subscriptionData = {
        sessionId,
        status: 'active',
        activatedAt: new Date().toISOString()
      };
    }
  }

  // Update in Firestore
  try {
    const db = adminDb();
    const docId = subscriptionData.subscriptionId || `sub_${sessionId}`;
    await db.collection('subscriptions').doc(docId).set(subscriptionData, { merge: true });

    if (subscriptionData.userId) {
      await db.collection('users').doc(subscriptionData.userId).set({
        vipStatus: 'active',
        vipPlanId: subscriptionData.planId,
        vipPlanName: subscriptionData.planName,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    }
  } catch (err) {
    console.warn('[Firestore] Error persisting verified subscription:', err);
  }

  return subscriptionData;
}
