/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { RefreshCw, Database, CreditCard } from 'lucide-react';
import { validateFirebaseConnection } from './lib/firebase';
import { subscribeToAppointments } from './lib/firestoreSync';
import { StripeUserPanelModal } from './components/StripeUserPanelModal';

const LOCAL_APP_URL = '/mirror/index.html';

export default function App() {
  const [reloadKey, setReloadKey] = useState(0);
  const [isFirebaseConnected, setIsFirebaseConnected] = useState(false);
  const [isStripeModalOpen, setIsStripeModalOpen] = useState(false);

  useEffect(() => {
    validateFirebaseConnection().then(connected => {
      setIsFirebaseConnected(connected);
    });

    const unsubscribe = subscribeToAppointments((appointments) => {
      console.log('[Firebase] Agendamentos sincronizados em tempo real:', appointments.length);
    });

    return () => unsubscribe();
  }, []);

  const handleRefresh = () => {
    setReloadKey((prev) => prev + 1);
  };

  return (
    <div className="fixed inset-0 w-full h-full bg-[#050505] overflow-hidden m-0 p-0">
      {/* 100% Local Self-Contained Barber App with Firebase & Stripe */}
      <iframe
        key={reloadKey}
        src={`${LOCAL_APP_URL}?_v=${reloadKey}`}
        title="Área VIP | Barbearia & Agendamentos"
        className="w-full h-full border-none block m-0 p-0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; geolocation; camera; microphone"
      />

      {/* Discrete status bar placed at top to never overlap bottom navigation */}
      <aside
        aria-label="Controle e status do sistema"
        className="fixed top-2.5 right-2.5 z-40 flex items-center gap-1.5 bg-black/75 hover:bg-black/95 backdrop-blur-md border border-zinc-800/80 rounded-full px-2 py-1 text-[11px] font-medium text-zinc-300 shadow-xl opacity-80 hover:opacity-100 transition-all duration-200"
      >
        {/* Stripe Subscription & Payment Panel trigger */}
        <button
          onClick={() => setIsStripeModalOpen(true)}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 hover:text-amber-200 border border-amber-500/30 text-[11px] font-bold transition-all shadow-sm"
          title="Abrir Painel de Assinaturas e Pagamentos Stripe"
        >
          <CreditCard className="w-3.5 h-3.5 text-amber-400" />
          <span>Assinatura Stripe</span>
        </button>

        {/* Firebase Live Status */}
        <div className="flex items-center gap-1 px-1.5 border-l border-zinc-800">
          <Database className={`w-3 h-3 ${isFirebaseConnected ? 'text-emerald-400' : 'text-zinc-500'}`} />
          <span className="hidden sm:inline text-[10px] text-zinc-300 font-mono">
            {isFirebaseConnected ? 'Firebase Ativo' : 'Conectando'}
          </span>
        </div>

        {/* Reload button */}
        <button
          onClick={handleRefresh}
          className="p-1 rounded-full hover:bg-zinc-800 text-zinc-400 hover:text-amber-400 transition-colors"
          title="Recarregar aplicativo"
        >
          <RefreshCw className="w-3 h-3" />
        </button>
      </aside>

      {/* Stripe User Panel & Subscriptions Modal */}
      <StripeUserPanelModal
        isOpen={isStripeModalOpen}
        onClose={() => setIsStripeModalOpen(false)}
      />
    </div>
  );
}
