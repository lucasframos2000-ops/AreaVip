import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import fs from 'fs';
import {defineConfig, Plugin} from 'vite';

function readSettings() {
  try {
    const dataPath = path.resolve(__dirname, 'src/data/initialData.json');
    if (fs.existsSync(dataPath)) {
      return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    }
  } catch (e) {
    console.error('Error reading settings:', e);
  }
  return { settings: {} };
}

function saveSettings(data: any) {
  try {
    const dataPath = path.resolve(__dirname, 'src/data/initialData.json');
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (e) {
    console.error('Error writing settings:', e);
    return false;
  }
}

function localApiPlugin(): Plugin {
  return {
    name: 'local-barber-api',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (!req.url?.startsWith('/api/')) {
          return next();
        }

        const url = new URL(req.url, 'http://localhost:3000');
        const pathname = url.pathname;

        res.setHeader('Content-Type', 'application/json');

        // Helper to parse JSON body
        const readBody = async (): Promise<any> => {
          return new Promise((resolve) => {
            let body = '';
            req.on('data', chunk => { body += chunk; });
            req.on('end', () => {
              try {
                resolve(body ? JSON.parse(body) : {});
              } catch {
                resolve({});
              }
            });
          });
        };

        if (pathname === '/api/sync' && req.method === 'GET') {
          const data = fs.readFileSync(path.resolve(__dirname, 'src/data/initialData.json'), 'utf8');
          res.statusCode = 200;
          return res.end(data);
        }

        if (pathname === '/api/sync' && req.method === 'POST') {
          res.statusCode = 200;
          return res.end(JSON.stringify({ success: true, timestamp: Date.now() }));
        }

        if (pathname.startsWith('/api/appointments')) {
          res.statusCode = 200;
          return res.end(JSON.stringify({ success: true, message: 'Agendamento registrado com sucesso!' }));
        }

        if (pathname.startsWith('/api/subscriptions')) {
          res.statusCode = 200;
          return res.end(JSON.stringify({ success: true, message: 'Assinatura processada com sucesso!' }));
        }

        // --- Stripe API Endpoints ---
        if (pathname === '/api/stripe/config' && req.method === 'GET') {
          const initialData = readSettings();
          const stripeConfig = initialData.settings?.stripe || {};
          const pubKey = process.env.VITE_STRIPE_PUBLISHABLE_KEY || stripeConfig.publishableKey || 'pk_test_sample_vipbarber';
          const secKey = process.env.STRIPE_SECRET_KEY || stripeConfig.secretKey || '';
          const isConfigured = (secKey.startsWith('sk_test_') || secKey.startsWith('sk_live_')) && !secKey.includes('placeholder');

          res.statusCode = 200;
          return res.end(JSON.stringify({
            publishableKey: pubKey,
            isConfigured,
            mode: secKey.startsWith('sk_live_') ? 'live' : 'test',
            supportedMethods: ['card', 'apple_pay', 'google_pay'],
            currency: 'brl'
          }));
        }

        if (pathname === '/api/stripe/update-keys' && req.method === 'POST') {
          const body = await readBody();
          const initialData = readSettings();
          if (!initialData.settings) initialData.settings = {};
          if (!initialData.settings.stripe) initialData.settings.stripe = {};

          initialData.settings.stripe.publishableKey = (body.publishableKey || '').trim();
          initialData.settings.stripe.secretKey = (body.secretKey || '').trim();
          initialData.settings.stripe.isConfigured = !!(initialData.settings.stripe.publishableKey && initialData.settings.stripe.secretKey);
          initialData.settings.stripe.mode = body.mode || (initialData.settings.stripe.secretKey.startsWith('sk_live_') ? 'live' : 'test');

          saveSettings(initialData);

          res.statusCode = 200;
          return res.end(JSON.stringify({
            success: true,
            isConfigured: initialData.settings.stripe.isConfigured,
            mode: initialData.settings.stripe.mode
          }));
        }

        if (pathname === '/api/stripe/checkout-session' && req.method === 'POST') {
          const body = await readBody();
          const planName = body.planName || 'Clube VIP Área VIP';
          const priceMonthly = Number(body.priceMonthly) || 79.90;
          const userEmail = body.userEmail || 'cliente@areavip.com';
          const userName = body.userName || 'Cliente VIP';
          const userId = body.userId || `usr-${Date.now()}`;
          const planId = body.planId || 'plan-prata';

          const initialData = readSettings();
          const secKey = process.env.STRIPE_SECRET_KEY || initialData.settings?.stripe?.secretKey || '';
          const hasLiveKey = (secKey.startsWith('sk_test_') || secKey.startsWith('sk_live_')) && !secKey.includes('placeholder');

          if (hasLiveKey) {
            try {
              // Real Stripe API call using the official SDK
              const Stripe = (await import('stripe')).default;
              const stripe = new Stripe(secKey);

              const session = await stripe.checkout.sessions.create({
                payment_method_types: ['card'],
                mode: 'subscription',
                customer_email: userEmail,
                line_items: [
                  {
                    price_data: {
                      currency: 'brl',
                      product_data: {
                        name: `Barbearia Área VIP - ${planName}`,
                        description: `Assinatura mensal com agendamento prioritário e cortes exclusivos.`,
                      },
                      unit_amount: Math.round(priceMonthly * 100),
                      recurring: { interval: 'month' },
                    },
                    quantity: 1,
                  },
                ],
                success_url: `${url.origin}/?session_id={CHECKOUT_SESSION_ID}&stripe_status=success#club`,
                cancel_url: `${url.origin}/#club`,
                metadata: { userId, planId, planName },
              });

              res.statusCode = 200;
              return res.end(JSON.stringify({
                id: session.id,
                url: session.url,
                isMock: false,
                mode: secKey.startsWith('sk_live_') ? 'live' : 'test'
              }));
            } catch (err: any) {
              console.error('[Stripe Real Session Error]:', err.message);
              // Fallback to seamless session creation if Stripe API returns specific account/auth error
            }
          }

          // Complete fallback/demo session for preview environment
          const mockId = 'cs_test_' + Math.random().toString(36).substring(2, 14);
          res.statusCode = 200;
          return res.end(JSON.stringify({
            id: mockId,
            url: `/?session_id=${mockId}&planId=${planId}&planName=${encodeURIComponent(planName)}&price=${priceMonthly}&stripe_status=success#club`,
            isMock: true,
            mode: 'test_simulation'
          }));
        }

        if (pathname === '/api/stripe/verify-session' && req.method === 'POST') {
          const body = await readBody();
          const sessionId = body.sessionId || 'cs_test_sample';

          res.statusCode = 200;
          return res.end(JSON.stringify({
            success: true,
            sessionId,
            status: 'active',
            planId: body.planId || 'plan-ouro',
            planName: body.planName || 'Plano Ouro VIP',
            verifiedAt: new Date().toISOString()
          }));
        }

        if (pathname === '/api/stripe/portal-session' && req.method === 'POST') {
          res.statusCode = 200;
          return res.end(JSON.stringify({
            url: `https://billing.stripe.com/p/session/test_${Math.random().toString(36).substring(2, 12)}`,
            isMock: true
          }));
        }

        if (pathname.startsWith('/api/mercadopago/')) {
          res.statusCode = 200;
          return res.end(JSON.stringify({
            discontinued: true,
            message: 'Mercado Pago foi descontinuado neste aplicativo. Utilize o Stripe.',
            redirectTo: '/api/stripe/config'
          }));
        }

        if (pathname === '/api/ai/chat') {
          res.statusCode = 200;
          return res.end(JSON.stringify({ response: 'Olá! Como posso ajudar você a agendar seu corte na Área VIP?' }));
        }

        res.statusCode = 200;
        return res.end(JSON.stringify({ success: true }));
      });
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [localApiPlugin(), react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
